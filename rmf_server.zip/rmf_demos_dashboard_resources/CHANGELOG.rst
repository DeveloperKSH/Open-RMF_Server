^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rmf_demos_dashboard_resources
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.3 (2023-12-20)
------------------
* Adding scale for icons (`#196 <https://github.com/open-rmf/rmf_demos/pull/196>`_)
* Contributors: Aaron Chong

2.2.2 (2023-08-28)
------------------

2.2.1 (2023-08-10)
------------------

2.2.0 (2023-06-08)
------------------

2.1.0 (2023-06-06)
------------------
* Switch to rst changelogs (`#182 <https://github.com/open-rmf/rmf_demos/pull/182>`_)
* Version updates from latest release synced to main (`#167 <https://github.com/open-rmf/rmf_demos/pull/167>`_)
* Contributors: Esteban Martinena Guerrero, Yadunund

2.0.2 (2022-10-10)
------------------

2.0.1 (2022-09-29)
------------------

1.3.0 (2021-09-08)
------------------
* Update icon for deliveryRobot: (`#79 <https://github.com/open-rmf/rmf_demos/pull/79>`_)

1.2.0 (2021-07-21)
------------------
* Move rmf_dashboard_resources to rmf_demos_dashboard_resources
* update all namings with rmf_demos as prefix (`#1 <https://github.com/open-rmf/rmf_demos/pull/1>`_)

1.X.X (2021-01-14)
------------------
* Add configs files for RMF web-based dashboard: (`#176 <https://github.com/osrf/rmf_demos/pull/176>`_)

1.0.0 (2020-09-24)
------------------
* Provides description and resource files for usage with the RMF Dashboard.
* Foxy (`#103 <https://github.com/osrf/rmf_demos/pull/103>`_)
* Contributors: Matias Bavera, Matías Bavera, Michael X. Grey, Teo Koon Peng, Yadu, koonpeng
