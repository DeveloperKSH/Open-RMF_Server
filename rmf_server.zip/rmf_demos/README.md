# rmf_demos

This package provides common launch files and shell scripts demonstrating how to build and start systems using RMF.

## Quality Declaration

This package claims to be in the **Quality Level 4** category, see the [Quality Declaration](./QUALITY_DECLARATION.md) for more details.
