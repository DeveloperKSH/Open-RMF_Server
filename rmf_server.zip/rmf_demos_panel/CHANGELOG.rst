^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rmf_demos_panel
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.3 (2023-12-20)
------------------

2.2.2 (2023-08-28)
------------------

2.2.1 (2023-08-10)
------------------
* Fix typo in readme (`#184 <https://github.com/open-rmf/rmf_demos/pull/184>`_)
* Contributors: Arjo Chakravarty, Yadunund

2.2.0 (2023-06-08)
------------------

2.1.0 (2023-06-06)
------------------
* Switch to rst changelogs (`#182 <https://github.com/open-rmf/rmf_demos/pull/182>`_)
* Fix conversion from minutes to milliseconds (`#176 <https://github.com/open-rmf/rmf_demos/pull/176>`_)
* Version updates from latest release synced to main (`#167 <https://github.com/open-rmf/rmf_demos/pull/167>`_)
* Contributors: Esteban Martinena Guerrero, Grey, Yadunund

2.0.2 (2022-10-10)
------------------

2.0.1 (2022-09-29)
------------------

1.3.0 (2021-09-08)
------------------
* Add API endpoint to get the building map: (`#75 <https://github.com/open-rmf/rmf_demos/pull/75>`_)

1.2.0 (2021-07-21)
------------------
* update all namings with rmf_demos as prefix (`#1 <https://github.com/open-rmf/rmf_demos/pull/1>`_)
* Add priority selection in dispatch scripts and react ui (`#5 <https://github.com/open-rmf/rmf_demos/pull/5>`_)
* Cleaning task demo in Airport terminal (`#8 <https://github.com/open-rmf/rmf_demos/pull/8>`_)
* Update build.yaml (`#16 <https://github.com/open-rmf/rmf_demos/pull/16>`_)
* Minor refactoring of api-server (`#25 <https://github.com/open-rmf/rmf_demos/pull/25>`_)

1.X.X (2021-01-14)
------------------
* RMF web-based dashboard: (`#176 <https://github.com/osrf/rmf_demos/pull/176>`_)
