# rmf_demos_gz_classic

This package provides top level launch files using the Gazebo-classic simulator demonstrating how to build and start systems using RMF.

## Quality Declaration

This package claims to be in the **Quality Level 4** category, see the [Quality Declaration](./QUALITY_DECLARATION.md) for more details.
