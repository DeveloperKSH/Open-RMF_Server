^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rmf_demos_tasks
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.3 (2023-12-20)
------------------

2.2.2 (2023-08-28)
------------------
* EasyFullControl integration with rmf_demos (`#158 <https://github.com/open-rmf/rmf_demos/pull/158>`_)
* Contributors: Aaron Chong, Grey, Xiyu, Yadunund

2.2.1 (2023-08-10)
------------------

2.2.0 (2023-06-08)
------------------

2.1.0 (2023-06-06)
------------------
* Switch to rst changelogs (`#182 <https://github.com/open-rmf/rmf_demos/pull/182>`_)
* Version updates from latest release synced to main (`#167 <https://github.com/open-rmf/rmf_demos/pull/167>`_)
* Contributors: Esteban Martinena Guerrero, Yadunund

2.0.2 (2022-10-10)
------------------

2.0.1 (2022-09-29)
------------------

1.2.0 (2021-07-21)
------------------
* update all namings with rmf_demos as prefix (`#1 <https://github.com/open-rmf/rmf_demos/pull/1>`_)
* Add priority selection in dispatch scripts and react ui (`#5 <https://github.com/open-rmf/rmf_demos/pull/5>`_)
* Cleaning task demo in Airport terminal (`#8 <https://github.com/open-rmf/rmf_demos/pull/8>`_)

1.1.0 (2020-09-24)
------------------
* Remove ament_python dependency. (`#92 <https://github.com/osrf/rmf_demos/pull/92>`_)
* Contributors: Aaron Chong, Kevin_Skywalker, Michael X. Grey, Yadu, kevinskwk, mrushyendra

1.0.0 (2020-06-24)
------------------
* Provides scripts for sending `Loop` and `Delivery` task requests to `rmf_fleet_adapters`
* Contributors: Aaron, Aaron Chong, Charayaphan Nakorn Boon Han, Geoffrey Biggs, Yadu, Yadunund
